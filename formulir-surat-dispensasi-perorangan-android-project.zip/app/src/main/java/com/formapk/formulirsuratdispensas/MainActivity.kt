package com.formapk.formulirsuratdispensas

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    data class FormLinkItem(val label: String, val description: String, val url: String)

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var splashOverlay: View
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var lastBackPressedAt: Long = 0L
    private var isOfflineFallbackShown = false
    private var activeLinkIndex: Int = 0
    private var currentActiveUrl: String = ""
    private lateinit var menuContainer: View
    private lateinit var contentContainer: View
    private var isShowingMenu: Boolean = true

    companion object {
        private const val FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLScm5QALwypL8XnnvD2PqmGk5JMIuzRyq1Jeias11Ms2qz5siQ/viewform?usp=send_form"
        private const val OFFLINE_ASSET_URL = "file:///android_asset/offline.html"
    }
    private val formLinks = listOf(
        FormLinkItem("Formulir Surat dispensasi perorangan", "", "https://docs.google.com/forms/d/e/1FAIpQLScm5QALwypL8XnnvD2PqmGk5JMIuzRyq1Jeias11Ms2qz5siQ/viewform?usp=send_form"),
        FormLinkItem("Formulir surat dispensasi kelompok", "", "https://docs.google.com/forms/d/e/1FAIpQLScqbNnT3wlzjiHnQJ-fgcwVACrE332zTG8TpT70yO6LmNci2Q/viewform?usp=send_form"),
        FormLinkItem("Formulir Surat dispensasi dengan lampiran", "", "https://docs.google.com/forms/d/e/1FAIpQLSehsvXMZdoJo97d2tKh3DF7K8gkAXApRtBxBevI1SxC5mNdcA/viewform?usp=send_form"),
        FormLinkItem("Formulir Surat Keterangan UTBK", "", "https://docs.google.com/forms/d/e/1FAIpQLSfvX90tNs12Uq-m5hBebsOxJVJ9U6Udz-hZe-UtTlYPiKf5gg/viewform?usp=send_form"),
        FormLinkItem("Formulir Surat Keterangan Mengikuti TKA", "", "https://docs.google.com/forms/d/e/1FAIpQLSfJ6adbMvCIdU8RNCMqfVh2uwnQyKQk_0icTLb7K_G3ni8-Rg/viewform?usp=send_form"),
        FormLinkItem("Formulir Panggilan Orang Tua", "", "https://docs.google.com/forms/d/e/1FAIpQLSeLN3fHztcdppYGjW9DCRiUv5qDMRc2--1qn_Jf0enBrHMEvg/viewform?usp=send_form"),
        FormLinkItem("Transkrip untuk kurikulum merdeka", "", "https://docs.google.com/forms/d/e/1FAIpQLScKfaDR-a23bpK-_5Nn60AoKWqlPs8spILGLAiqqPBAvvlJbA/viewform?usp=send_form"),
        FormLinkItem("Formulir surat keterangan untuk UPN", "", "https://docs.google.com/forms/d/e/1FAIpQLSea3y-qli6hGsMpJQfnSY-o3aD6kAsIBcN9u_vWkh_2bdHhsA/viewform?usp=send_form"),
        FormLinkItem("Formulir Transkrip nilai 16", "", "https://docs.google.com/forms/d/e/1FAIpQLSe12F639ujAQ2A5mRLLxhK5Ek6CzyVAQZ2-cyTAmkE3rEn93g/viewform?usp=send_form"),
        FormLinkItem("Formulir keterangan melakukan penelitian", "", "https://docs.google.com/forms/d/e/1FAIpQLSet-Z9zrEhh6psLESLz-oHdZNji7R6xl87s3xK0eEbP7sbh1g/viewform?usp=send_form"),
        FormLinkItem("Formulir keterangan tidak ada un", "", "https://docs.google.com/forms/d/e/1FAIpQLSdniry6NaCO2oOIYdi5DuLGb4RJddqBoVj0frI1k0eU7_t-cQ/viewform?usp=send_form"),
        FormLinkItem("Formulir surat tidak ada un", "", "https://docs.google.com/forms/d/e/1FAIpQLSdpCi0dNyl4Juq84_YL4gNzX35XqT5BUclzDC-4PbPMAyB-Wg/viewform?usp=send_form"),
        FormLinkItem("Formulir Keterangan Tidak ada UN", "", "https://docs.google.com/forms/d/e/1FAIpQLScsnAQb4ylv0oi_k7I6At3PDLdrndQBjzVHWWjPrG1QJMO0dg/viewform?usp=send_form"),
        FormLinkItem("Formulir Panggilan Orang Tua", "", "https://docs.google.com/forms/d/e/1FAIpQLSed0E5sp2ftpQvh4h_uyG51LWrxxuiCRH9fuPe88a_fW6YR6Q/viewform?usp=send_form"),
        FormLinkItem("Formulir Resset HP", "", "https://docs.google.com/forms/d/e/1FAIpQLSfxDqomp73INf4B8YV94CvcEZVwHXJP4q8J0EwvO482Kh12Kw/viewform?usp=send_form"),
        FormLinkItem("Formulir SPPD", "", "https://docs.google.com/forms/d/e/1FAIpQLSfUj482i5jX5dYeojJCCHZ2_wDrFEfUnHhYkuH_Xt7m4TuBMA/viewform?usp=send_form"),
        FormLinkItem("Formulir surat keterangan siswa", "", "https://docs.google.com/forms/d/e/1FAIpQLSewMUzAfkzLoaJC-n-6-dyNWs7M8ZakZTNgonvN557Lf4tsmQ/viewform?usp=send_form")
    )

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = filePathCallback ?: return@registerForActivityResult
        val results = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        callback.onReceiveValue(results)
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        splashOverlay = findViewById(R.id.splashOverlay)
        menuContainer = findViewById(R.id.menuContainer)
        contentContainer = findViewById(R.id.contentContainer)
        
        findViewById<ImageButton>(R.id.btnRefresh)?.setOnClickListener {
            isOfflineFallbackShown = false
            if (webView.url == OFFLINE_ASSET_URL) {
                webView.loadUrl(if (currentActiveUrl.isNotBlank()) currentActiveUrl else FORM_URL)
            } else {
                webView.reload()
            }
        }
        findViewById<ImageButton>(R.id.btnHome)?.setOnClickListener {
            showMenuPortal()
        }

        configureWebView()
        setupBackNavigation()

        swipeRefresh.setColorSchemeResources(R.color.colorPrimary)
        swipeRefresh.setOnRefreshListener {
            isOfflineFallbackShown = false
            if (webView.url == OFFLINE_ASSET_URL) {
                webView.loadUrl(if (currentActiveUrl.isNotBlank()) currentActiveUrl else FORM_URL)
            } else {
                webView.reload()
            }
        }

        setupMenuPortal()
        if (savedInstanceState != null) {
            isShowingMenu = savedInstanceState.getBoolean("isShowingMenu", true)
            activeLinkIndex = savedInstanceState.getInt("activeLinkIndex", 0)
            currentActiveUrl = formLinks.getOrNull(activeLinkIndex)?.url ?: FORM_URL
            if (!isShowingMenu) {
                menuContainer.visibility = View.GONE
                contentContainer.visibility = View.VISIBLE
                webView.restoreState(savedInstanceState)
            }
        } else {
            showMenuPortal()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            splashOverlay.animate().alpha(0f).setDuration(260).withEndAction {
                splashOverlay.visibility = View.GONE
            }.start()
        }, 1200L)
    }

    private fun setupMenuPortal() {
        val listLayout = findViewById<LinearLayout>(R.id.menuListLayout)
        listLayout.removeAllViews()

        val density = resources.displayMetrics.density
        val padH = (16 * density).toInt()
        val padV = (14 * density).toInt()
        val marginBottom = (12 * density).toInt()

        formLinks.forEachIndexed { index, item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(padH, padV, padH, padV)
                setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
                isClickable = true
                isFocusable = true
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = marginBottom
                layoutParams = lp
            }

            val titleTv = TextView(this).apply {
                text = "${index + 1}. ${item.label}"
                textSize = 15f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#0F172A"))
            }
            card.addView(titleTv)

            if (item.description.isNotBlank()) {
                val descTv = TextView(this).apply {
                    text = item.description
                    textSize = 12f
                    setPadding(0, (4 * density).toInt(), 0, 0)
                    setTextColor(Color.parseColor("#475569"))
                }
                card.addView(descTv)
            }

            card.setOnClickListener {
                openFormLink(index)
            }
            listLayout.addView(card)
        }
    }

    private fun openFormLink(index: Int) {
        activeLinkIndex = index
        val item = formLinks[index]
        currentActiveUrl = item.url
        isShowingMenu = false
        isOfflineFallbackShown = false
        menuContainer.visibility = View.GONE
        contentContainer.visibility = View.VISIBLE
        findViewById<TextView>(R.id.toolbarTitle)?.text = item.label
        webView.loadUrl(item.url)
    }

    private fun showMenuPortal() {
        isShowingMenu = true
        menuContainer.visibility = View.VISIBLE
        contentContainer.visibility = View.GONE
        findViewById<TextView>(R.id.toolbarTitle)?.text = getString(R.string.app_name)
        progressBar.visibility = View.GONE
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.userAgentString = settings.userAgentString.replace("; wv", "")

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url ?: return false
                val host = uri.host.orEmpty()
                val scheme = uri.scheme.orEmpty()

                if (scheme == "file" || host.endsWith("google.com") || host == "forms.gle" || host.endsWith("googleusercontent.com") || host.endsWith("gstatic.com")) {
                    return false
                }

                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url != OFFLINE_ASSET_URL) {
                    progressBar.visibility = View.VISIBLE
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { CookieManager.getInstance().flush() }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    if (!isOfflineFallbackShown) {
                        isOfflineFallbackShown = true
                        view?.loadUrl(OFFLINE_ASSET_URL)
                    }
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress >= 100) {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    fileChooserLauncher.launch(intent)
                    true
                } catch (_: Exception) {
                    this@MainActivity.filePathCallback = null
                    Toast.makeText(this@MainActivity, "Tidak dapat membuka pemilih berkas", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!isShowingMenu) {
                    if (webView.canGoBack() && webView.url != OFFLINE_ASSET_URL) {
                        webView.goBack()
                    } else {
                        showMenuPortal()
                    }
                    return
                }
                val now = System.currentTimeMillis()
                if (now - lastBackPressedAt < 2000L) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                } else {
                    lastBackPressedAt = now
                    Toast.makeText(
                        this@MainActivity,
                        "Tekan sekali lagi untuk keluar",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("activeLinkIndex", activeLinkIndex)
        outState.putBoolean("isShowingMenu", isShowingMenu)
        webView.saveState(outState)
    }
}

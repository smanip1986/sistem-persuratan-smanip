# Formulir Surat dispensasi perorangan

Proyek Android WebView ini dibuat otomatis oleh **Form2APK Studio** untuk membungkus 17 tautan Google Form menjadi 1 aplikasi Android (.apk):

- **Package ID**: `com.formapk.formulirsuratdispensas`
- **Versi**: 1.0.0 (Build 1)
- **Mode Navigasi Multi-Link**: `menu_home`
- **Daftar Tautan**:
  1. **Formulir Surat dispensasi perorangan**: https://docs.google.com/forms/d/e/1FAIpQLScm5QALwypL8XnnvD2PqmGk5JMIuzRyq1Jeias11Ms2qz5siQ/viewform?usp=send_form
  2. **Formulir surat dispensasi kelompok**: https://docs.google.com/forms/d/e/1FAIpQLScqbNnT3wlzjiHnQJ-fgcwVACrE332zTG8TpT70yO6LmNci2Q/viewform?usp=send_form
  3. **Formulir Surat dispensasi dengan lampiran**: https://docs.google.com/forms/d/e/1FAIpQLSehsvXMZdoJo97d2tKh3DF7K8gkAXApRtBxBevI1SxC5mNdcA/viewform?usp=send_form
  4. **Formulir Surat Keterangan UTBK**: https://docs.google.com/forms/d/e/1FAIpQLSfvX90tNs12Uq-m5hBebsOxJVJ9U6Udz-hZe-UtTlYPiKf5gg/viewform?usp=send_form
  5. **Formulir Surat Keterangan Mengikuti TKA**: https://docs.google.com/forms/d/e/1FAIpQLSfJ6adbMvCIdU8RNCMqfVh2uwnQyKQk_0icTLb7K_G3ni8-Rg/viewform?usp=send_form
  6. **Formulir Panggilan Orang Tua**: https://docs.google.com/forms/d/e/1FAIpQLSeLN3fHztcdppYGjW9DCRiUv5qDMRc2--1qn_Jf0enBrHMEvg/viewform?usp=send_form
  7. **Transkrip untuk kurikulum merdeka**: https://docs.google.com/forms/d/e/1FAIpQLScKfaDR-a23bpK-_5Nn60AoKWqlPs8spILGLAiqqPBAvvlJbA/viewform?usp=send_form
  8. **Formulir surat keterangan untuk UPN**: https://docs.google.com/forms/d/e/1FAIpQLSea3y-qli6hGsMpJQfnSY-o3aD6kAsIBcN9u_vWkh_2bdHhsA/viewform?usp=send_form
  9. **Formulir Transkrip nilai 16**: https://docs.google.com/forms/d/e/1FAIpQLSe12F639ujAQ2A5mRLLxhK5Ek6CzyVAQZ2-cyTAmkE3rEn93g/viewform?usp=send_form
  10. **Formulir keterangan melakukan penelitian**: https://docs.google.com/forms/d/e/1FAIpQLSet-Z9zrEhh6psLESLz-oHdZNji7R6xl87s3xK0eEbP7sbh1g/viewform?usp=send_form
  11. **Formulir keterangan tidak ada un**: https://docs.google.com/forms/d/e/1FAIpQLSdniry6NaCO2oOIYdi5DuLGb4RJddqBoVj0frI1k0eU7_t-cQ/viewform?usp=send_form
  12. **Formulir surat tidak ada un**: https://docs.google.com/forms/d/e/1FAIpQLSdpCi0dNyl4Juq84_YL4gNzX35XqT5BUclzDC-4PbPMAyB-Wg/viewform?usp=send_form
  13. **Formulir Keterangan Tidak ada UN**: https://docs.google.com/forms/d/e/1FAIpQLScsnAQb4ylv0oi_k7I6At3PDLdrndQBjzVHWWjPrG1QJMO0dg/viewform?usp=send_form
  14. **Formulir Panggilan Orang Tua**: https://docs.google.com/forms/d/e/1FAIpQLSed0E5sp2ftpQvh4h_uyG51LWrxxuiCRH9fuPe88a_fW6YR6Q/viewform?usp=send_form
  15. **Formulir Resset HP**: https://docs.google.com/forms/d/e/1FAIpQLSfxDqomp73INf4B8YV94CvcEZVwHXJP4q8J0EwvO482Kh12Kw/viewform?usp=send_form
  16. **Formulir SPPD**: https://docs.google.com/forms/d/e/1FAIpQLSfUj482i5jX5dYeojJCCHZ2_wDrFEfUnHhYkuH_Xt7m4TuBMA/viewform?usp=send_form
  17. **Formulir surat keterangan siswa**: https://docs.google.com/forms/d/e/1FAIpQLSewMUzAfkzLoaJC-n-6-dyNWs7M8ZakZTNgonvN557Lf4tsmQ/viewform?usp=send_form

---

## Cara 1: Build Menjadi File `.apk` Gratis Tanpa Install Android Studio (GitHub Actions)

1. Buat repositori baru (bisa Private atau Public) di [GitHub](https://github.com/new).
2. Ekstrak file ZIP ini, lalu unggah seluruh isi folder (termasuk folder `.github`) ke repositori tersebut.
3. Buka tab **Actions** di repositori GitHub Anda.
4. Klik workflow **Build Android APK** (jika belum berjalan otomatis, klik tombol **Run workflow**).
5. Tunggu sekitar 1-2 menit hingga status berubah hijau, lalu unduh file **`app-debug.apk`** di bagian **Artifacts** di halaman tersebut.
6. Kirim `app-debug.apk` ke HP Android Anda dan instal!

---

## Cara 2: Build Langsung di Laptop Menggunakan Android Studio

1. Ekstrak file ZIP ini.
2. Buka **Android Studio** -> **Open** -> pilih folder proyek ini.
3. Tunggu proses Gradle Sync selesai.
4. Klik menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. File `.apk` siap diambil di folder `app/build/outputs/apk/debug/app-debug.apk`.
